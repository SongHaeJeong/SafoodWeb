/*
-- Query: SELECT * FROM safood.user
LIMIT 0, 1000

-- Date: 2019-05-16 17:10
*/
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('123','123','123','cjsong8942@hanmail.net');
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('admin','admin','관리자','ssafy.com');
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('cjsong','1111','시제이송',' asdjklsa@naver.com');
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('cjsonghae','1234','Á¤¼ÛÇØ','cjsong8942@hanmail.net');
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('nsa0911','1234','������','cjsong8942@hanmail.net');
INSERT INTO `user` (`id`,`pass`,`name`,`email`) VALUES ('ssafy','1234','cjsong','hahah@haha.com');
