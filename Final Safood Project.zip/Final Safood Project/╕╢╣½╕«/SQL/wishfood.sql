/*
-- Query: SELECT * FROM safood.wishfood
LIMIT 0, 1000

-- Date: 2019-05-16 17:10
*/
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (39,'admin',2);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (44,'cjsong',2);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (47,'cjsong',2);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (48,'cjsong',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (49,'cjsong',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (50,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (51,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (52,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (53,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (54,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (55,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (56,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (57,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (58,'admin',1);
INSERT INTO `wishfood` (`wishfoodid`,`user_id`,`food_code`) VALUES (59,'admin',1);
