/*
-- Query: SELECT * FROM safood.notice
LIMIT 0, 1000

-- Date: 2019-05-16 17:08
*/
INSERT INTO `notice` (`nid`,`title`,`content`,`ndate`,`count`,`img`) VALUES (15,'1414','1414','2019-05-13',1,NULL);
INSERT INTO `notice` (`nid`,`title`,`content`,`ndate`,`count`,`img`) VALUES (16,'1313','13131','2019-05-13',0,NULL);
INSERT INTO `notice` (`nid`,`title`,`content`,`ndate`,`count`,`img`) VALUES (17,'안녕?','안녕','2019-05-13',0,NULL);
INSERT INTO `notice` (`nid`,`title`,`content`,`ndate`,`count`,`img`) VALUES (18,'화요일이니?','화요일이여','2019-05-14',3,NULL);
