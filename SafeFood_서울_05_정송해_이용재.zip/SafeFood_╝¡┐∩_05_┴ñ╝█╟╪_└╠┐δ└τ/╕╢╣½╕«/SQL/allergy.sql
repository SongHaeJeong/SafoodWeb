/*
-- Query: SELECT * FROM safood.allergy
LIMIT 0, 1000

-- Date: 2019-05-16 17:06
*/
INSERT INTO `allergy` (`aid`,`name`) VALUES (1,'대두');
INSERT INTO `allergy` (`aid`,`name`) VALUES (2,'땅콩');
INSERT INTO `allergy` (`aid`,`name`) VALUES (3,'우유');
INSERT INTO `allergy` (`aid`,`name`) VALUES (4,'돼지고기');
INSERT INTO `allergy` (`aid`,`name`) VALUES (5,'계란');
INSERT INTO `allergy` (`aid`,`name`) VALUES (6,'소고기');
INSERT INTO `allergy` (`aid`,`name`) VALUES (7,'새우');
INSERT INTO `allergy` (`aid`,`name`) VALUES (8,'연어');
