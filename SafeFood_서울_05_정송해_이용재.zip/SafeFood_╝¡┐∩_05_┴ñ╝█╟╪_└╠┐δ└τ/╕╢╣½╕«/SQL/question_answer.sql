/*
-- Query: SELECT * FROM safood.question
LIMIT 0, 1000

-- Date: 2019-05-16 17:08
*/
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (8,'cjsonghae','오늘은 금요일','2019-05-10','지려버립니다');
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (11,'cjsonghae','123123','2019-05-10','123123');
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (12,'cjsonghae','123213','2019-05-10','123123');
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (13,'cjsonghae','77','2019-05-10','');
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (15,'ssafy','qweqwe','2019-05-10','qweqwe');
INSERT INTO `question_answer` (`qid`,`userid`,`title`,`wdate`,`content`) VALUES (16,'admin','','2019-05-16','');
