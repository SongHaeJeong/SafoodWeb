/*
-- Query: SELECT * FROM safood.user_has_allergy
LIMIT 0, 1000

-- Date: 2019-05-16 17:10
*/
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (1,'ssafy',1);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (2,'ssafy',2);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (3,'ssafy',3);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (4,'admin',2);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (7,'admin',2);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (9,'123',2);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (10,'123',5);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (11,'123',8);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (12,'admin',2);
INSERT INTO `user_has_allergy` (`uaid`,`user_id`,`allergy_aid`) VALUES (13,'admin',2);
