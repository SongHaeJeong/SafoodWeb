/*
-- Query: SELECT * FROM safood.food_has_allergy
LIMIT 0, 1000

-- Date: 2019-05-16 17:08
*/
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (1,2,1);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (2,2,2);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (3,2,3);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (4,2,4);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (5,2,5);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (6,3,1);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (7,3,2);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (8,3,3);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (9,3,4);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (10,3,5);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (11,4,7);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (12,5,5);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (13,7,2);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (14,9,1);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (15,9,2);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (16,10,1);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (17,17,3);
INSERT INTO `food_has_allergy` (`faid`,`food_code`,`allergy_aid`) VALUES (18,19,3);
